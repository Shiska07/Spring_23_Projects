Name: Shiska Raut
ID: 1001526329

Files:

1) Data_Analysis_and_Model_Selection.ipynb: This notebook contains the data analysis part where correlation and distribution of various features with respect to the target variable were analyzed. It also contains the part were different classification models were compared using test data accuracy.

2) Final_Training_and_Cross_Validation.ipynb: This notebook contains solution to the project implemented using the best classification model tested in the 'Data_Analysis_and_Model_Selection' notebook.

3) Raut_p2_summary.txt: This word document contains project summary and details of various steps taken to improve accuracy. 